from setuptools import setup

setup(name='onestCaptcha',version='1.0',author='onestCaptcha',author_email='onestCaptcha@support.com',packages=["onestCaptcha"])